const out = document.getElementById("out");
const btn = document.getElementById("btn");

function show(type, data) {
  out.className = "out " + type;
  out.textContent = typeof data === "string" ? data : JSON.stringify(data, null, 2);
}

btn.addEventListener("click", async () => {
  try {
    show("info", "A processar...");
    const body = {
      accountId: document.getElementById("accountId").value.trim(),
      numbers: document.getElementById("numbers").value.trim(),
      stars: document.getElementById("stars").value.trim()
    };

    const resp = await fetch("/api/place-bet", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    const data = await resp.json();
    if (!resp.ok) {
      return show("error", `Erro (${data.step || "App"}): ${data.error || "Falhou"}`);
    }

    show("success",
      `Registo concluído.\n` +
      `Tracking: ${data.receipt.trackingCode}\n` +
      `Saldo restante: ${data.remainingBalance} créditos\n\n` +
      `Detalhes:\n${JSON.stringify(data, null, 2)}`
    );
  } catch (e) {
    show("error", "Erro inesperado: " + String(e));
  }
});
