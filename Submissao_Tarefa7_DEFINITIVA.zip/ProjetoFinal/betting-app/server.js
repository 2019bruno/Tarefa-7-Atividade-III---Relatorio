const express = require("express");
const fetch = (...args) => import("node-fetch").then(({ default: fetch }) => fetch(...args));

const app = express();
app.use(express.json());
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const CREDBANK_URL = process.env.CREDBANK_URL || "http://localhost:3001";
const EUROMIL_URL = process.env.EUROMIL_URL || "http://localhost:3002";

function parseIntsArray(str, expectedLen) {
  const parts = (str || "")
    .split(",")
    .map(s => s.trim())
    .filter(Boolean)
    .map(n => Number(n));

  if (parts.length !== expectedLen) return { error: `Expected ${expectedLen} values` };
  if (parts.some(n => !Number.isInteger(n))) return { error: "All values must be integers" };
  return { values: parts };
}

function validateKey(numbers, stars) {
  const nums = new Set(numbers);
  const sts = new Set(stars);
  if (nums.size !== 5) return "numbers must be unique";
  if (sts.size !== 2) return "stars must be unique";
  for (const n of numbers) if (n < 1 || n > 50) return "numbers must be 1..50";
  for (const s of stars) if (s < 1 || s > 12) return "stars must be 1..12";
  return null;
}

app.post("/api/place-bet", async (req, res) => {
  try {
    const { accountId, numbers, stars } = req.body || {};
    if (!accountId) return res.status(400).json({ error: "accountId is required" });

    const nums = parseIntsArray(numbers, 5);
    if (nums.error) return res.status(400).json({ error: "Invalid numbers: " + nums.error });

    const sts = parseIntsArray(stars, 2);
    if (sts.error) return res.status(400).json({ error: "Invalid stars: " + sts.error });

    const keyError = validateKey(nums.values, sts.values);
    if (keyError) return res.status(400).json({ error: keyError });

    // 1) Solicitar cheque ao CrediBank
    const chequeResp = await fetch(`${CREDBANK_URL}/api/cheques/issue`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountId, amount: 10, purpose: "EUROMIL_BET" })
    });
    const chequeData = await chequeResp.json();
    if (!chequeResp.ok) {
      return res.status(400).json({ step: "CrediBank", error: chequeData.error || "Failed to issue cheque" });
    }

    // 2) Registar aposta no EuroMilRegister
    const regResp = await fetch(`${EUROMIL_URL}/api/bets/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        key: { numbers: nums.values, stars: sts.values },
        cheque: chequeData.cheque,
        signature: chequeData.signature
      })
    });
    const regData = await regResp.json();
    if (!regResp.ok) {
      return res.status(400).json({ step: "EuroMilRegister", error: regData.error || "Failed to register bet" });
    }

    return res.status(201).json({
      message: "Bet registered successfully",
      bet: regData.bet,
      receipt: regData.receipt,
      remainingBalance: chequeData.account?.remainingBalance
    });
  } catch (err) {
    return res.status(500).json({ error: "Unexpected server error", detail: String(err) });
  }
});

app.listen(PORT, () => {
  console.log(`BettingApp running on http://localhost:${PORT}`);
});
