# ProjetoFinal — Aplicação de Apostas Online (Tipo Euromilhões)

## Componentes
- **BettingApp (Web)**: interface e orquestração do processo de aposta
- **CrediBank API**: valida conta/saldo, debita 10 créditos e emite cheque digital assinado
- **EuroMilRegister API**: valida cheque e regista aposta

## Executar (recomendado) — Docker Compose
1. Instalar Docker e Docker Compose
2. Na pasta `ProjetoFinal`, executar:
   - `docker compose up`
3. Abrir a aplicação em:
   - `http://localhost:3000`

## Executar (manual) — Node.js 18+
### 1) CrediBank
- `cd credibank-api`
- `npm install`
- `set CREDBANK_SECRET=super_secret_credibank_key` (Windows) ou `export CREDBANK_SECRET=...` (Linux/Mac)
- `node server.js`

### 2) EuroMilRegister
- `cd ../euromilregister-api`
- `npm install`
- `set CREDBANK_SECRET=super_secret_credibank_key`
- `node server.js`

### 3) BettingApp
- `cd ../betting-app`
- `npm install`
- `set CREDBANK_URL=http://localhost:3001`
- `set EUROMIL_URL=http://localhost:3002`
- `node server.js`
- Abrir `http://localhost:3000`

## Contas de teste
- `CB-10001` (saldo 120)
- `CB-20002` (saldo 30)
- `CB-30003` (saldo 5 — insuficiente)
