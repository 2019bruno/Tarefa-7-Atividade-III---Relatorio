const express = require("express");
const crypto = require("crypto");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3002;
const SECRET = process.env.CREDBANK_SECRET || "super_secret_credibank_key";

const usedCheques = new Set();
const bets = [];

function verifySignature(cheque, signature) {
  const expected = crypto
    .createHmac("sha256", SECRET)
    .update(JSON.stringify(cheque))
    .digest("hex");
  return expected === signature;
}

function validateKey(key) {
  if (!key || typeof key !== "object") return "key is required";
  const { numbers, stars } = key;
  if (!Array.isArray(numbers) || numbers.length !== 5) return "numbers must have 5 values";
  if (!Array.isArray(stars) || stars.length !== 2) return "stars must have 2 values";

  const nset = new Set(numbers);
  const sset = new Set(stars);
  if (nset.size !== 5) return "numbers must be unique";
  if (sset.size !== 2) return "stars must be unique";

  for (const n of numbers) {
    if (!Number.isInteger(n) || n < 1 || n > 50) return "numbers must be integers between 1 and 50";
  }
  for (const s of stars) {
    if (!Number.isInteger(s) || s < 1 || s > 12) return "stars must be integers between 1 and 12";
  }
  return null;
}

app.get("/health", (req, res) => res.json({ ok: true, service: "EuroMilRegister" }));

/**
 * POST /api/bets/register
 * Regista aposta com cheque digital assinado.
 */
app.post("/api/bets/register", (req, res) => {
  const { key, cheque, signature } = req.body || {};

  const keyError = validateKey(key);
  if (keyError) return res.status(400).json({ error: keyError });

  if (!cheque || typeof cheque !== "object") return res.status(400).json({ error: "cheque is required" });
  if (!signature || typeof signature !== "string") return res.status(400).json({ error: "signature is required" });

  if (cheque.amount !== 10 || cheque.currency !== "CREDITS") {
    return res.status(400).json({ error: "invalid cheque amount/currency (expected 10 CREDITS)" });
  }
  if (cheque.purpose !== "EUROMIL_BET") {
    return res.status(400).json({ error: "invalid cheque purpose" });
  }

  const exp = Date.parse(cheque.expiresAt);
  if (!Number.isFinite(exp) || exp < Date.now()) {
    return res.status(400).json({ error: "cheque expired" });
  }

  if (usedCheques.has(cheque.chequeId)) {
    return res.status(409).json({ error: "cheque already used" });
  }

  if (!verifySignature(cheque, signature)) {
    return res.status(401).json({ error: "invalid cheque signature" });
  }

  usedCheques.add(cheque.chequeId);

  const bet = {
    betId: crypto.randomUUID(),
    registeredAt: new Date().toISOString(),
    key,
    accountId: cheque.accountId,
    chequeId: cheque.chequeId,
    amount: cheque.amount,
    status: "REGISTERED"
  };
  bets.push(bet);

  const receipt = {
    receiptId: crypto.randomUUID(),
    betId: bet.betId,
    trackingCode: "EMR-" + crypto.randomBytes(4).toString("hex").toUpperCase()
  };

  return res.status(201).json({ bet, receipt });
});

app.get("/api/bets", (req, res) => {
  res.json({ total: bets.length, bets });
});

app.listen(PORT, () => {
  console.log(`EuroMilRegister API running on http://localhost:${PORT}`);
});
