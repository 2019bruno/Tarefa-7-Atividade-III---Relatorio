const express = require("express");
const crypto = require("crypto");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3001;
const SECRET = process.env.CREDBANK_SECRET || "super_secret_credibank_key";

// Contas de demonstração (simulação de base de dados)
const accounts = new Map([
  ["CB-10001", { owner: "Conta Teste 1", balance: 120 }],
  ["CB-20002", { owner: "Conta Teste 2", balance: 30 }],
  ["CB-30003", { owner: "Conta Teste 3", balance: 5 }]
]);

function signCheque(payload) {
  return crypto.createHmac("sha256", SECRET)
    .update(JSON.stringify(payload))
    .digest("hex");
}

app.get("/health", (req, res) => res.json({ ok: true, service: "CrediBank" }));

/**
 * POST /api/cheques/issue
 * Emite cheque digital de 10 créditos para apostas.
 */
app.post("/api/cheques/issue", (req, res) => {
  const { accountId, amount, purpose } = req.body || {};

  if (!accountId || typeof accountId !== "string") {
    return res.status(400).json({ error: "accountId is required" });
  }
  if (!Number.isInteger(amount) || amount <= 0) {
    return res.status(400).json({ error: "amount must be a positive integer" });
  }
  if (purpose !== "EUROMIL_BET") {
    return res.status(400).json({ error: "purpose must be EUROMIL_BET" });
  }

  const acc = accounts.get(accountId);
  if (!acc) return res.status(404).json({ error: "account not found" });

  if (acc.balance < amount) {
    return res.status(402).json({ error: "insufficient credits" });
  }

  // Debita e emite cheque
  acc.balance -= amount;

  const cheque = {
    chequeId: crypto.randomUUID(),
    accountId,
    amount,
    currency: "CREDITS",
    issuedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString(), // 5 minutos
    purpose,
    nonce: crypto.randomBytes(16).toString("hex")
  };

  const signature = signCheque(cheque);

  return res.status(201).json({
    cheque,
    signature,
    account: { owner: acc.owner, remainingBalance: acc.balance }
  });
});

app.listen(PORT, () => {
  console.log(`CrediBank API running on http://localhost:${PORT}`);
});
